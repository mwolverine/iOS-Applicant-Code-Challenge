/*:
## About Me

Tell us a little bit about yourself using Swift variables. Start with your first name, your last name, your age, where you're from, and why you want to take the class.
*/
let firstName: String = "Chris"
let lastName: String = "Yoo"
let age: Int = 23
let from: String = "Europe, Asia, Africa, and North America"
let why: String = "to learn how to code and work on my startup idea"

//: Create an array of Strings that holds a few of your hobbies.
var hobbyArray: [String] = ["traveling", "hiking", "reading", "taking pictures"]

/*: 
Programmatically combine the individual strings from your hobbies array into a single string with the hobbies separated by commas.

For example: "Programming, Teaching, Golf, and Basketball."
*/
let hobbyString = hobbyArray.joinWithSeparator(", ")

//: Using the variables you have created, write a programmatically generated sentence to introduce yourself. Use only one print() statement.

print ("Hi. I am \(firstName) \(lastName). I am \(age) old. I have lived in \(from). I am here \(why). In my free time, I enjoy \(hobbyString).")

//: [Previous](@previous)
//: [Next](@next)
