/*:
## Basic Math

Demonstrate basic knowledge of functions that take parameters and return results by implementing some basic math functions.
*/
//: Write a function that returns the sum of two numbers

func addTwo (a: Int, b: Int) -> Int {
    return a+b
}

//: Write a function that returns the product of two numbers
func multiplyTwo (a: Int, b: Int) -> Int {
    return a*b
}
//: Write a function that returns the average (mean) of an array of numbers
func averageNumbers (numbers: Double...) -> Double {
    var total: Double = 0
    for i in numbers {
        total += i
    }
    return total / Double(numbers.count)
}

//: Demo the use of your functions here:
print (addTwo(5, b: 5))
print (multiplyTwo(5, b: 5))
print (averageNumbers(5, 10, 15))



//: [Previous](@previous)
//: [Next](@next)
